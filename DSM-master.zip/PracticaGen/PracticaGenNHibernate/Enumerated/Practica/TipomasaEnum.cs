
using System;

namespace PracticaGenNHibernate.Enumerated.Practica
{
public enum TipoMasaEnum { extra_fina=1, clasica=2, gruesa=3, rellena_de_queso=4 };
}
