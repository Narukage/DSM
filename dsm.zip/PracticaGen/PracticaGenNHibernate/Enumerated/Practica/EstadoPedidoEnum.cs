
using System;

namespace PracticaGenNHibernate.Enumerated.Practica
{
public enum EstadoPedidoEnum { pendiente=1, recibido=2, rechazado=3 };
}
