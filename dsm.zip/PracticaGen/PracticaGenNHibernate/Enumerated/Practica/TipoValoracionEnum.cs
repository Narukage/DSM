
using System;

namespace PracticaGenNHibernate.Enumerated.Practica
{
public enum TipoValoracionEnum { sin_valorar=0, mala=1, regular=2, buena=3, muybuena=4, excelente=5 };
}
