
using System;
using System.Text;
using System.Collections.Generic;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;
using PracticaGenNHibernate.Exceptions;
using PracticaGenNHibernate.EN.Practica;
using PracticaGenNHibernate.CAD.Practica;
using System.Net.Mail;
using System.Text;



/*PROTECTED REGION ID(usingPracticaGenNHibernate.CEN.Practica_Registrado_recuperarContrasenya) ENABLED START*/
//  references to other libraries
/*PROTECTED REGION END*/

namespace PracticaGenNHibernate.CEN.Practica
{
public partial class RegistradoCEN
{
public void RecuperarContrasenya (string p_oid)
{
        /*PROTECTED REGION ID(PracticaGenNHibernate.CEN.Practica_Registrado_recuperarContrasenya) ENABLED START*/

        // Write here your custom code...

            RegistradoEN registradoEN = _IRegistradoCAD.ReadOID(p_oid);



            SmtpClient client = new SmtpClient();
            client.Port = 587;
            client.Host = "smtp.gmail.com";
            client.EnableSsl = true;
            client.Timeout = 10000;
            client.DeliveryMethod = SmtpDeliveryMethod.Network;
            client.UseDefaultCredentials = false;
            client.Credentials = new System.Net.NetworkCredential("epizza.servicios@gmail.com", "dsm-master");

            int longitud = 8;
            string caracteres = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            StringBuilder nuevacontrasenya = new StringBuilder();
            Random generaraleatorio = new Random();
            while (0 < longitud--)
            {
                nuevacontrasenya.Append(caracteres[generaraleatorio.Next(caracteres.Length)]);
            }
            String clave = nuevacontrasenya.ToString();
            String mensaje = ("Servicio E-PIZZA. Su nueva contrase�a es la siguiente: \n" + clave + "\n\nMuchas gracias por confiar en nosotros. Tus mejores pizzas siempre aqu�. :) ");
            MailMessage mm = new MailMessage(registradoEN.Email, registradoEN.Email, "Recuperar contrase�a", mensaje);
            mm.BodyEncoding = UTF8Encoding.UTF8;
            mm.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

            client.Send(mm);


        /*PROTECTED REGION END*/
}
}
}
