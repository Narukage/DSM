
using System;

namespace PracticaGenNHibernate.Enumerated.Practica
{
public enum TipoPagoEnum { paypal=1, tarjeta=2, contrarreembolso=3 };
}
