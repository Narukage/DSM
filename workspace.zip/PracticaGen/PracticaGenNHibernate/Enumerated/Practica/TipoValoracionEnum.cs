
using System;

namespace PracticaGenNHibernate.Enumerated.Practica
{
public enum TipoValoracionEnum { mala=1, regular=2, buena=3, muybuena=4, excelente=5 };
}
