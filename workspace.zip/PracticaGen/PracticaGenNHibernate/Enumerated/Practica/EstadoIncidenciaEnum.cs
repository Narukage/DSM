
using System;

namespace PracticaGenNHibernate.Enumerated.Practica
{
public enum EstadoIncidenciaEnum { pendiente=1, resuelta=2 };
}
