
using System;
// Definición clase AdminEN
namespace PracticaGenNHibernate.EN.Practica
{
public partial class AdminEN                                                                        : PracticaGenNHibernate.EN.Practica.RegistradoEN


{
/**
 *	Atributo incidencia
 */
private System.Collections.Generic.IList<PracticaGenNHibernate.EN.Practica.IncidenciaEN> incidencia;






public virtual System.Collections.Generic.IList<PracticaGenNHibernate.EN.Practica.IncidenciaEN> Incidencia {
        get { return incidencia; } set { incidencia = value;  }
}





public AdminEN() : base ()
{
        incidencia = new System.Collections.Generic.List<PracticaGenNHibernate.EN.Practica.IncidenciaEN>();
}



public AdminEN(string email, System.Collections.Generic.IList<PracticaGenNHibernate.EN.Practica.IncidenciaEN> incidencia
               , string nombre, String contrasenya, Nullable<DateTime> fecha_nac, int telefono
               )
{
        this.init (Email, incidencia, nombre, contrasenya, fecha_nac, telefono);
}


public AdminEN(AdminEN admin)
{
        this.init (Email, admin.Incidencia, admin.Nombre, admin.Contrasenya, admin.Fecha_nac, admin.Telefono);
}

private void init (string email
                   , System.Collections.Generic.IList<PracticaGenNHibernate.EN.Practica.IncidenciaEN> incidencia, string nombre, String contrasenya, Nullable<DateTime> fecha_nac, int telefono)
{
        this.Email = email;


        this.Incidencia = incidencia;

        this.Nombre = nombre;

        this.Contrasenya = contrasenya;

        this.Fecha_nac = fecha_nac;

        this.Telefono = telefono;
}

public override bool Equals (object obj)
{
        if (obj == null)
                return false;
        AdminEN t = obj as AdminEN;
        if (t == null)
                return false;
        if (Email.Equals (t.Email))
                return true;
        else
                return false;
}

public override int GetHashCode ()
{
        int hash = 13;

        hash += this.Email.GetHashCode ();
        return hash;
}
}
}
