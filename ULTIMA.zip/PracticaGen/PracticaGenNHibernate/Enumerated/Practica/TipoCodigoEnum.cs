
using System;

namespace PracticaGenNHibernate.Enumerated.Practica
{
public enum TipoCodigoEnum { pizza=1, bebida=2, complemento=3 };
}
