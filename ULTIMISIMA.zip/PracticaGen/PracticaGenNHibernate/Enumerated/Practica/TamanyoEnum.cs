
using System;

namespace PracticaGenNHibernate.Enumerated.Practica
{
public enum TamanyoEnum { pequenya=1, normal=2, familiar=3 };
}
